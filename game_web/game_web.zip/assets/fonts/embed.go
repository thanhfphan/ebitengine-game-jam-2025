package fonts

import (
	_ "embed"
)

var (
	//go:embed Nunito-Regular.ttf
	NunitoRegular_ttf []byte
)
